# Evaluation: run-1793341207-0acf90 — status **INCONCLUSIVE**

> ENGINE: model (kind=unknown)

- inconclusive: startup: 0 valid cold generations < 1 planned
- inconclusive: startup: runner attached to an already running server (no cold launch); clock measures attach-to-first-valid only

## Population
| planned | offered | completed | failed | unfinished | evidence_invalid |
| --- | --- | --- | --- | --- | --- |
| 11 | 11 | 9 | 1 | 1 | 0 |

## Startup: launch -> first VALID generation: median None s over 0 launch(es)

## Cells
| cell | load | completed/offered | TTFT p50 s [CI] | TTFT p90 s | FI strict mean | FI relaxed SLO | MDD p99 s | FTGR tok/s | rejections |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| control_a | conc=1 | 3/3 | 0.06145 [0.04866, 0.0617] | 0.06165 | 1 | True | 0.01752 | 57.07 | - |
| control_b | conc=1 | 3/3 | 0.05767 [0.05584, 0.059] | 0.05873 | 1 | True | 0.01751 | 57.11 | - |
| delay100 | conc=1 | 3/3 | 0.1612 [0.1531, 0.1646] | 0.1639 | 1 | True | 0.01582 | 63.23 | - |
| earlyclose | conc=1 | 0/1 | - [-, -] | - | 0 | False | - | - | {'missing_done': 1, 'missing_finish_reason': 1, 'invalid_output': 2} |
| wrongnonce | conc=1 | 0/1 | - [-, -] | - | 0 | False | - | - | {'invalid_output': 1} |
