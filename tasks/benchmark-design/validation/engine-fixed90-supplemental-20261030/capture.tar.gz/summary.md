# Evaluation: run-1793366023-8e0ea4 — status **INCONCLUSIVE**

> ENGINE: model (kind=unknown)

- inconclusive: startup: 0 valid cold generations < 1 planned
- inconclusive: startup: runner attached to an already running server (no cold launch); clock measures attach-to-first-valid only

## Population
| planned | offered | completed | failed | unfinished | evidence_invalid |
| --- | --- | --- | --- | --- | --- |
| 90 | 90 | 90 | 0 | 0 | 0 |

## Startup: launch -> first VALID generation: median None s over 0 launch(es)

## Cells
| cell | load | completed/offered | TTFT p50 s [CI] | TTFT p90 s | FI strict mean | FI relaxed SLO | MDD p99 s | FTGR tok/s | rejections |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| control_a | conc=1 | 30/30 | 0.06254 [0.06218, 0.06287] | 0.06419 | 1 | True | 0.01781 | 56.16 | - |
| control_b | conc=1 | 30/30 | 0.06258 [0.06224, 0.06378] | 0.06451 | 1 | True | 0.01881 | 53.15 | - |
| delay100 | conc=1 | 30/30 | 0.1626 [0.1625, 0.1629] | 0.1647 | 1 | True | 0.0161 | 62.11 | - |
